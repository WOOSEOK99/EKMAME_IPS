원본: gunbird2m.zip
각 IPS 파일은 같은 이름의 원본 칩에 적용합니다.
Korean_Translation.dat에는 원본 CRC가 들어 있습니다.
